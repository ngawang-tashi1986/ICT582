import matplotlib.pyplot as plt
import numpy as np
import datetime
import customer

def get_months(db):
    date_check =''
    months = []
    for t in np.sort(db, order="date"):
        if date_check != str(t['date'])[:7]:
            date_check = str(t['date'])[:7]
            months.append(date_check)
    return months

def get_Y(X,db,opt='count'):
    arr_sale = []
    arr_count = []
    for x in X:
        sales = count = 0
        for t in db:
            if str(t['date'])[:7] == x:
                sales += t['value']
                count += 1
        arr_sale.append(sales)
        arr_count.append(count)

    if opt == 'count':
        arr_count = np.array(arr_count)
        return arr_count
    else:
        arr_sale = np.array(arr_sale)
        return arr_sale

def get_scale(n):
    if n < 100:
        scale = 1
    elif n < 1000:
        scale = 10
    elif n < 10000:
        scale = 100
    else:
        scale = 1000
    return scale

def monthly_sales_transactions(sales_db):
    if len(sales_db) == 0:
        print('[system notification]: Transaction database is empty. Returning to Main Menu..')
    else:
        X = []
        
        sorted_trans = np.sort(sales_db, order="date")
        X = get_months(sales_db)
        scaler = get_scale(np.max(get_Y(X,sales_db,'sale')))
        
        plt.plot(X, np.divide(get_Y(X,sales_db,'sale'),scaler), 'go-', label='Sale Value')
        plt.plot(X, get_Y(X,sales_db), 'b*--', label='Transaction Count')
        plt.xticks(rotation=45)
        plt.title('Monthly Sale Values (in '+str(scaler)+'s) and Transaction Count Graph')
        plt.xlabel('Month-Year')
        plt.ylabel('Count')
        plt.legend(loc='best')
        plt.show()

def customer_monthly_sales(c_db, sales_db):
    if len(c_db) == 0 or len(sales_db) == 0:
        print('[system notification]: Transaction or Customer database is empty. Returning to Main Menu..')
    else:
        print("View customer's monthly sale value and transaction graph.")
        print('If you are not sure of Customer ID, type "help" to view the customer list.')

        while True:
            print("\nType 'exit' to go back to Main Menu.")
            user_input = input('Customer ID: ')
            if user_input.lower() == 'exit':
                break
            
            elif user_input == 'help':
                customer.get_customers_details(c_db)
                
            elif user_input.isdigit():
                transactions = []
                customer = []
                customer_id = int(user_input)
                for cust in c_db:
                    if cust['customer_id'] == customer_id:
                        customer = cust
                        for transaction in sales_db:
                            if transaction['customer_id'] == customer_id:
                                transactions.append(transaction)
                        break
                    
                months = get_months(transactions)
                

                scaler = get_scale(np.max(get_Y(months,transactions,'sale')))
                
                plt.plot(months, np.divide(get_Y(months,transactions,'sale'),scaler), 'go-', label='Sale Value')
                plt.plot(months, get_Y(months,transactions), 'b*--', label='Transaction Count')
                plt.xticks(rotation=45)
                plt.title('Monthly Sale Values(in '+str(scaler)+'s) and Transaction Count Graph of '+customer['name']+'('+str(customer['customer_id'])+')')
                plt.xlabel('Month-Year')
                plt.ylabel('Count')
                plt.legend(loc='best')
                plt.show()
                
            else:
                print('[system notification]: The Customer ID did not match with any customer in the database.\n')

def postcode_monthly_sales(c_db, sales_db):
    if len(c_db) == 0 or len(sales_db) == 0:
        print('[system notification]: Transaction or Customer database is empty. Returning to Main Menu..')
    else:
        print("View monthly sale value and transaction graph based on postcode.")

        while True:
            print("\nType 'exit' to go back to Main Menu.")
            user_input = input('Postcode: ')
            if user_input.lower() == 'exit':
                break
            
            else:
                transactions = []
                customers = []

                for cust in c_db:
                    if cust['postcode'] == user_input:
                        customers.append(cust)
                        for transaction in sales_db:
                            if transaction['customer_id'] == cust['customer_id']:
                                transactions.append(transaction)
                    
            

                if len(customers) == 0:
                    print('[system notification]: Entered postcode did not match any record in the database. Please try again.')
                else:
                    months = get_months(transactions)
                    
                    scaler = get_scale(np.max(get_Y(months,transactions,'sale')))

                    plt.plot(months, np.divide(get_Y(months,transactions,'sale'),scaler), 'go-', label='Sale Value')
                    plt.plot(months, get_Y(months,transactions), 'b*--', label='Transaction Count')
                    plt.xticks(rotation=45)
                    plt.title('Monthly Sale Values(in '+str(scaler)+'s) and Transaction Count Graph Based on Postcode '+user_input)
                    plt.xlabel('Month-Year')
                    plt.ylabel('Count')
                    plt.legend(loc='best')
                    plt.show()
