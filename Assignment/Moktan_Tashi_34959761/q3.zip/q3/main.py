import sys
from utility import *
import customer as customer
import sales
import graph

customers_db = []
sales_db = []

args = sys.argv[1:]

if len(args) == 2:
    customers_db, sales_db = load_csv_data(args[0], args[1])

print(f"\n{'Western Wholesales Pty Ltd':^120}")    

while True:   
    line_style_underscore(120)
    print("M A I N    M E N U ")
    line_style_hyphen(120)
    print(f"{'1. Load customer records': <40}  {'2. Load sales Record':40} {'3. Save customer records to a CSV file':40}")
    print(f"{'4. Save sales records to a CSV file':40} {'5. Add New Customer Record':40} {'6. Add New Sales Record':40}")
    print(f"{'7. Search customer record':40} {'8. Search sales record':40} {'9. Search customers sales record':40}")
    print(f"{'10. Delete sale record':40} {'11. Delete customer':40} {'12. Display Sales Graph':40}")
    print(f"{'13. Display Sales Grapy By Customer':40} {'14. Display Sales Graph by Post':40}")
    print(f"{'15. Quit':40}")
    line_style_underscore(120)

    choice = input("\nEnter your choice : ")
    
    if choice == '1':
        customer.load_customer_csv(customers_db)

    elif choice == '2':
        sales.load_sales_csv(sales_db)  

    elif choice == '3':
        customer_filename = input("Enter customer file name      : ")
        customer.save_customer_records(customer_filename,customers_db)

    elif choice == '4':
        sales_filename = input("Enter sales file name      : ")
        sales.save_sales_record(sales_filename,sales_db)

    elif choice == '5':
        customer.add_new_customer(customers_db)

    elif choice == '6':
        sales.add_new_sales_record(sales_db,customers_db)

    elif choice == '7':
        customer.search_customer_record(customers_db)

    elif choice == '8':
        sales.search_sales_record(sales_db)

    elif choice == '9':
        sales.search_sales_record(sales_db)

    elif choice == '10':
        sales.delete_sales_record(sales_db)

    elif choice == '11':
        customer.delete_customer_record(customers_db,sales_db)

    elif choice == '12':
        graph.monthly_sales_transactions(sales_db)
        
    elif choice == '13':
        graph.customer_monthly_sales(customers_db,sales_db)

    elif choice == '14':
        graph.postcode_monthly_sales(customers_db,sales_db)

    elif choice == '15':
        print("Exiting Program !!!")
        break
    else:
        print("Invalid choice. Please try again !!!")
    

        
