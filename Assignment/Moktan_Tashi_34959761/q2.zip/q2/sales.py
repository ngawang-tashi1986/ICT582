import utility
import os
import csv
import customer

def check_customer(cust_id, customers_db):
    flag = False
    for item in customers_db:
        if item['cust_id'] == cust_id:
            flag = True
            break
    return flag

def load_sales_csv(sales_db):
    while True:
        print("\nType 'exit' to go back to Main Menu.")
        file_name = input('Enter sales file name      : ')
        try:
            if file_name.lower() == 'exit':
                break

            if os.path.getsize(file_name) == 0:
                print('The specified file is empty. Please provide a csv file with content.')
            else:
                with open(file_name, newline='', encoding='utf-8-sig') as file:
                    reader = csv.DictReader(file)
                    # Extracting the records and adding to the transaction database
                    total = count = 0
                    if len(sales_db) == 0:
                        trans_id = 100000000
                    else:
                        trans_id = sales_db[-1]['trans_id']+1
                    for row in reader:
                        total += 1
                        if row['customer_id'].isdigit():
                            sales_db.append({
                                'trans_id' : trans_id,
                                'customer_id' : int(row['customer_id']),
                                'date' : row['date'],
                                'category' : row['category'],
                                'value' : row['value']
                                })
                            count+=1
                            trans_id += 1
                            print('.',end='')
                        else:
                            print('Customer ID does not exist in the database.',row,'has been ignored.')
                        
                print('\n',count,'out of',total,'transaction record(s) imported successfully from the csv file.')
             
        except FileNotFoundError:
            print(f"The file {file_name} does not exist.")
        except PermissionError:
            print(f"The permission denied for file {file_name} to read/write.")
        except IndexError:
            print(f"The file {file_name} does not meet the given required format.")
        except:
            print('Something went wrong.') 


#Function to save/export whole csv record.
def save_sales_record(file_path,sales):
    if not sales:
        print("No sales records to save.")
        return
    
    if os.path.exists(file_path):
        overwrite = input(f"File {file_path} already exists. Do you want to overwrite it? (yes/no): ")
        if overwrite.lower() != 'yes':
            return

    with open(file_path, 'w',  encoding="utf-8", newline='') as csvfile:
        fieldnames = ['date', 'trans_id', 'customer_id', 'category', 'value']
        writer = csv.writer(csvfile)
        writer.writerow(fieldnames)
        for sale in sales:
            writer.writerow(sale)
    print(f"Sales records saved to {file_path}.")

#Add new sales record
def add_new_sales_record(sales_db, customer_db):
    if len(customer_db) == 0:
            print('Please add a customer before recording a transaction. Returning to Main Menu..')
    else:
        print('If you are not sure of Customer ID, type "help" to view the customer list.')

        while True:
            print("Type 'exit' to go back to Main Menu.")
            user_input = input('Enter Customer ID to add transaction record: ')
            if user_input == 'help':
                customer.get_customers_details(customer_db)
                
            elif user_input.lower() == 'exit':
                break

            elif user_input.isdigit():
                if len(sales_db) == 0:
                    trans_id = 100000000
                else:
                    trans_id = int(sales_db[-1].get('trans_id')+1)

                customer_id = int(user_input)
                if check_customer(customer_id, customer_db):
                    date = input("Enter transactionn date [yyyy-mm-dd]  : ")
                    category = input("Enter transactionn category           : ")
                    value = float(input("Enter transactionn value              : "))
                    sales_db.append({
                        'transaction_id' : trans_id,
                        'customer_id' : customer_id,
                        'date' : date,
                        'category' : category,
                        'value' : value
                        })
                    print('New transaction has been instertedsuccessfully.\n')
                else:
                    print('The entered Customer ID was not found in the Customer Database. ')
            else:
                print('Please enter valid Customer ID.\n')



#Function to search sales record
def search_sales_record(sales_db):
    if len(sales_db) == 0:
        print('Sales record is empty. Please load the sales record')
    else:
        while True:
            search_result = []
            print("\nType 'exit' to go back to Main Menu.")
            keyword = input('Type in a keyword to search the sales record : ')

            if keyword.lower() == 'exit':
                break

            for transaction in sales_db:
                for item in transaction:
                    if keyword.lower() in str(transaction[item]).lower():
                        search_result.append(transaction)
                        break
        
            if len(search_result) == 0:
                print('Your search keyword did not match anything in the sales record. Please try again')
            else:
                print('Search Result\n')
                print(f"{'ID':<10} {'Customer ID':<11} {'Date':>15} {'Category':20} {'Value':>10}")
                for item in search_result:
                    print(f"{item.get('trans_id'):<10} {item.get('customer_id'):<11} {item.get('date'):>15} {item.get('category'):20} {item.get('value'):10}")


#Function to display sale history for given customer
def show_sales_per_customer(customer_db, sales_db):
    
    if len(customer_db) == 0 or len(sales_db) == 0:
        print(' There is no data to search. Please load the data')
    else:
        print('If you are not sure of Customer ID, type "help" to view the customer list.')
        while True:
            transactions = []
            customer = ''
            print("\nType 'exit' to go back to Main Menu.")
            user_input = input('Type in a customer id to search the sales record : ')
            if user_input.lower() == 'exit':
                break
            elif user_input == 'help':
                customer.get_customers_details(customer_db)
            elif user_input.isdigit():
                customer_id = int(user_input)
                for cust in customer_db:
                    if cust['customer_id'] == customer_id:
                        customer = cust
                        break
                for transaction in sales_db:
                    if transaction['customer_id'] == customer_id:
                        transactions.append(transaction)

                if customer == '':
                    print('The Customer ID did not match with any customer in the database.\n')
                else:
                    print('CUSTOMER INFORMARION')
                    print(f"{'Customer ID:':>14} {customer.get('cust_id')}")
                    print(f"{'Name:':>14} {customer.get('name')}")
                    print(f"{'Postcode:':>14} {customer.get('postcode')}")
                    print(f"{'Mobile Number:':>14} {customer.get('phone')}")
                    
                    print('\n SALES HISTORY')
                    if len(transactions) == 0:
                        print(customer.get('name'),'has no transaction history.\n')
                    else:
                        print(f"{'ID':<11} {'Date':>15} \t {'Category':20} {'Value':>10}")
                        for trans in transactions:
                            print(f"{trans.get('trans_id'):<11} {trans.get('date'):>15} \t {trans.get('category'):20} {trans.get('value'):>10}")
            else:
                print('The Customer ID did not match with any customer in the database.\n')

#Function to delete sales record using transaction ID
def delete_sales_record(sales_db):
    if len(sales_db) == 0:
        print('Sales is empty. Please load the sales record')
    else:
        print('Type "help" to view the transaction list.')
        while True:
            flag = 0
            print("\nType 'exit' to go back to Main Menu.")
            user_input = input('Enter the Transaction ID to Delete : ')

            if user_input.lower() == 'exit':
                break
            elif user_input == 'help':            
                get_sales_record(sales_db)
            elif user_input.isdigit():
                for transaction in sales_db:
                    if transaction.get('trans_id') == int(user_input):
                        print('You are about to delete following transaction:')
                        print(transaction)
                        confirmation = input('Are you sure? yes for yes, anything else for no: ')
                        if confirmation.lower() == 'yes' or confirmation.lower() == 'y':
                            sales_db.remove(transaction)
                            flag = 1
                        break
                if flag == 0:
                    print('Delete operation canceled.\n')
                elif flag == 1:
                    print('Sales record has been deleted successfully.\n')
                else:
                    print('The Transaction ID did not match any transaction in the database.\n')
            else:
                print('Please enter valid Transaction ID.\n')


def get_sales_record(sales_db):
    print('Viewing Sales Record')
    print(f"{'Transaction ID':>15} {'Date':15} {'Category':20} {'Value':>10}")
    for sales in sales_db:
        print(f"{sales.get('trans_id'):>15} {sales.get('date'):15} {sales.get('category'):20} {sales.get('value'):10}")
