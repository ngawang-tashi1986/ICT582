import utility
import os
import csv

# Function to load customer csv files
def load_customer_csv(customers_db):
    while True:
        print("\nType 'exit' to go back to Main Menu.")
        file_name = input('Enter customer file name      : ')
        try:
            if file_name.lower() == 'exit':
                break

            if os.path.getsize(file_name) == 0:
                print('The specified file is empty. Please provide a csv file with content.')
            else:
                with open(file_name, newline='', encoding='utf-8-sig') as file:
                    reader = csv.DictReader(file)
                    total = count = 0
                    for row in reader:
                        total += 1
                        if row['cust_id'].isdigit():
                            flag = 0
                            for customer in customers_db:
                                if int(row['cust_id']) == customer.get('cust_id'):
                                    flag = 1
                                    break
                            if flag == 0:
                                customers_db.append({
                                    'cust_id': int(row['cust_id']),
                                    'name': row['name'],
                                    'postcode': row['postcode'],
                                    'phone': row['phone'],
                                })
                                count += 1
                                print('.', end='')
                            else:
                                print('Customer with same ID already exist in the database.',row,'has been ignored.')
                        else:
                            print('',row,'doesnot have a valid Customer ID. Customer ID needs to be an integer.')
                        
                print('\n',count,'out of',total,'customer record(s) imported successfully from the csv file.')
             
        except FileNotFoundError:
            print(f"The file {file_name} does not exist.")
        except PermissionError:
            print(f"The permission denied for file {file_name} to read/write.")
        except IndexError:
            print(f"The file {file_name} does not meet the given required format.")
        except:
            print('Something went wrong.')   

#Function to save/export whole csv record.
def save_customer_records(file_path, customers):
    if not customers:
        print("No customer records to save.")
        return
    
    if os.path.exists(file_path):
        overwrite = input(f"File {file_path} already exists. Do you want to overwrite it? (yes/no): ")
        if overwrite.lower() != 'yes':
            return

    with open(file_path, 'w', newline='') as csvfile:
        fieldnames = ['cust_id', 'name', 'postcode', 'phone']
        writer = csv.writer(csvfile)
        writer.writerow(fieldnames)
        for customer in customers:
            writer.writerow(customer)
    print(f"Customer records saved to {file_path}.")


# Function to add new customers to csv file
def add_new_customer(customer_db):
    print('Please provide the following information.')
    if len(customer_db) == 0:
        cust_id = 100000
    else:
        cust_id = int(customer_db[-1].get('cust_id')+1)
    name = utility.get_validated_input('Customer Name           : ', utility.is_alpha)
    postcode = utility.get_validated_input('Postcode (optional)     :', utility.is_digit)
    phone = utility.get_validated_input('Phone Number (optional) :', utility.is_digit)

    customer_db.append({
        'cust_id': cust_id,
        'name': name,
        'postcode': postcode,
        'phone': phone,
        })
    latest_customer = customer_db[-1]
    print('New customer (',latest_customer['name'],') has been added with Customer ID:',latest_customer['cust_id'],'\n')

#Function to search customer record
def search_customer_record(customer_db):
    if len(customer_db) == 0:
        print('Customer database is empty. Please load the customer details to search')
    else:
        while True:
            search_result = []
            print("\nType 'exit' to go back to Main Menu.")
            keyword = input('Type in a keyword to search the customer record : ')

            if keyword.lower() == 'exit':
                break
            
            for customer in customer_db:
                for item in customer:
                    if keyword.lower() in str(customer[item]).lower():
                        search_result.append(customer)
                        break
        
            if len(search_result) == 0:
                print('Your search keyword did not match any customer record. Please try again.\n')
            else:
                print('Search Result\n')
                print(f"{'Customer ID':10} {'Name':30} {'Postcode':>10} {'Mobile Number':>15}")
                for item in search_result:
                    print(f"{item.get('cust_id'):<10} {item.get('name'):30} {item.get('postcode'):>10} {item.get('phone'):>15}")

#Function to delete customer record
def delete_customer_record(customer_db,sales_db):
    if len(customer_db) == 0:
        print('Customer database is empty. Please load the record')
    else:
        print('If you are not sure of Customer ID, type "help" to view the customer list.')
        while True:
            customer = {}
            transactions = []
            flag = 0
            print("\nType 'exit' to go back to Main Menu.")
            user_input = input('Enter the Customer ID to Delete  : ')

            if user_input.lower() == 'exit':
                break
            elif user_input == 'help':            
                get_customers_details(customer_db)
            elif user_input.isdigit():
                for cust in customer_db:
                    if cust.get('cust_id') == int(user_input):
                        customer = cust
                        flag = 1
                        for trans in sales_db:
                            if trans.get('customer_id') == int(user_input):
                                transactions.append(trans)
                        break
                    
                if flag == 1:
                    print('You are about to delete following customer and sales details:')
                    print('CUSTOMER INFORMATION')
                    print(f"{'Customer ID:':>14} {customer.get('cust_id')}")
                    print(f"{'Name:':>14} {customer.get('name')}")
                    print(f"{'Postcode:':>14} {customer.get('postcode')}")
                    print(f"{'Mobile Number:':>14} {customer.get('phone number')}")

                    print('SALES HISTORY')
                    if len(transactions) != 0:
                        print(f"{'ID':<5} {'Date':<15} \t {'Category':20}")
                        for t in transactions:
                            print(f"{t.get('trans_id'):<5} {t.get('date'):<15} \t {t.get('category'):20}")
                    else:
                        print(' No transaction record found.')

                    confirmation = input('Are you sure? yes for YES, anything else for NO: ')
                    if confirmation.lower() == 'yes' or confirmation.lower() == 'y':
                        if len(transactions) != 0:
                            for trans in transactions:
                                sales_db.remove(trans)
                   
                        customer_db.remove(customer)   
                        print('Customer has been deleted successfully.\n')
                    else:
                        print('Delete operation has been canceled.\n')
                else:
                    print('The Customer ID did not match any customer in the database.\n')
            else:
                print('The Customer ID did not match any customer in the database.\n')


def get_customers_details(customer_db):
    print("%11s: %s" %('Customer ID','Name'))
    for customer in customer_db:
        print("%11d: %s" %(customer['cust_id'],customer['name']))
          
