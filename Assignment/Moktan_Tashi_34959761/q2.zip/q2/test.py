import csv
import os
import sys

# Data structure to hold customer and sales records
customers = []
sales = []

def load_records(customer_file, sales_file):
    global customers, sales
    customers.clear()
    sales.clear()
    
    # Load customer records
    with open(customer_file, newline='') as csvfile:
        reader = csv.reader(csvfile)
        next(reader)  # Skip header
        for row in reader:
            cust_id = row[0]
            name = row[1]
            postcode = row[2] if len(row) > 2 else ''
            phone = row[3] if len(row) > 3 else ''
            customers.append((cust_id, name, postcode, phone))

    # Load sales records
    with open(sales_file, newline='') as csvfile:
        reader = csv.reader(csvfile)
        next(reader)  # Skip header
        for row in reader:
            date = row[0]
            trans_id = row[1]
            customer_id = row[2]
            category = row[3]
            value = row[4]
            sales.append((date, trans_id, customer_id, category, value))

def save_customers(file_path):
    if not customers:
        print("No customer records to save.")
        return
    
    if os.path.exists(file_path):
        overwrite = input(f"File {file_path} already exists. Do you want to overwrite it? (yes/no): ")
        if overwrite.lower() != 'yes':
            return

    with open(file_path, 'w', newline='') as csvfile:
        fieldnames = ['cust_id', 'name', 'postcode', 'phone']
        writer = csv.writer(csvfile)
        writer.writerow(fieldnames)
        for customer in customers:
            writer.writerow(customer)
    print(f"Customer records saved to {file_path}.")

def save_sales(file_path):
    if not sales:
        print("No sales records to save.")
        return
    
    if os.path.exists(file_path):
        overwrite = input(f"File {file_path} already exists. Do you want to overwrite it? (yes/no): ")
        if overwrite.lower() != 'yes':
            return

    with open(file_path, 'w', newline='') as csvfile:
        fieldnames = ['date', 'trans_id', 'customer_id', 'category', 'value']
        writer = csv.writer(csvfile)
        writer.writerow(fieldnames)
        for sale in sales:
            writer.writerow(sale)
    print(f"Sales records saved to {file_path}.")

def main():
    if len(sys.argv) == 3:
        load_records(sys.argv[1], sys.argv[2])

    while True:
        print("\nMenu:")
        print("1. Load customer and sales records from CSV files")
        print("2. Save customer records to a CSV file")
        print("3. Save sales records to a CSV file")
        print("4. Quit")
        
        choice = input("Enter your choice: ")
        
        if choice == '1':
            customer_file = input("Enter the customer records file name: ")
            sales_file = input("Enter the sales records file name: ")
            try:
                load_records(customer_file, sales_file)
                print("Records loaded successfully.")
            except Exception as e:
                print(f"Error loading records: {e}")
        
        elif choice == '2':
            if customers:
                file_path = input("Enter the file name to save customer records: ")
                save_customers(file_path)
            else:
                print("No customer and sales records in memory.")

        elif choice == '3':
            if sales:
                file_path = input("Enter the file name to save sales records: ")
                save_sales(file_path)
            else:
                print("No customer and sales records in memory.")

        elif choice == '4':
            print("Quitting the program.")
            break

        else:
            print("Invalid choice. Please try again.")

if __name__ == "__main__":
    main()
