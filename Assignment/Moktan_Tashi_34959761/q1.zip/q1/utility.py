import csv
import os


# The following methods load the csv from the current working directory.
# The methods takes in file name of the csv file.
""" def load_csv_file(fileName, type):
    current_working_dir = os.path.dirname(os.path.abspath(__file__)) # Get current working directory
    file_path = os.path.join(current_working_dir, fileName)
    try:
        with open(file_path, 'r', newline='', encoding='utf-8') as file:
            content = file.read()
            print(f"{type} data loaded sucessfully !!!")
        return content
    except FileNotFoundError:
        print(f"The file {fileName} does not exist.")
        return False
    except PermissionError:
        print(f"No permission to read the file {fileName}.")
        return False
    except Exception as e:
        print(f"An error occurred: {e}")
        return False

def load_csv_data(csv_file_name, type):
    csv_data = load_csv_file(csv_file_name, type)
    return csv_data"""
def load_csv_file(fileName, type):
    current_working_dir = os.path.dirname(os.path.abspath(__file__)) # Get current working directory
    file_path = os.path.join(current_working_dir, fileName)
    try:
        with open(file_path, 'r', newline='', encoding='utf-8') as file:
            content = file.read()
            print(f"{type} data loaded sucessfully !!!")
        return content
    except FileNotFoundError:
        print(f"The file {fileName} does not exist.")
        return False
    except PermissionError:
        print(f"No permission to read the file {fileName}.")
        return False
    except Exception as e:
        print(f"An error occurred: {e}")
        return False
    
def load_csv_data(csv_file_name, type):
    csv_data = load_csv_file(csv_file_name, type)
    return csv_data

# Function to save customer records to a CSV file
def save_customers(file_path, customers):
    if not customers:
        print("No customer records to save.")
        return
    
    if os.path.exists(file_path):
        overwrite = input(f"File {file_path} already exists. Do you want to overwrite it? (yes/no): ")
        if overwrite.lower() != 'yes':
            return

    with open(file_path, 'w', newline='') as csvfile:
        fieldnames = ['cust_id', 'name', 'postcode', 'phone']
        writer = csv.writer(csvfile)
        writer.writerow(fieldnames)
        for customer in customers:
            writer.writerow(customer)
    print(f"Customer records saved to {file_path}.")

# Function to save sale records to a CSV file
def save_sales(file_path,sales):
    if not sales:
        print("No sales records to save.")
        return
    
    if os.path.exists(file_path):
        overwrite = input(f"File {file_path} already exists. Do you want to overwrite it? (yes/no): ")
        if overwrite.lower() != 'yes':
            return

    with open(file_path, 'w',  encoding="utf-8", newline='') as csvfile:
        fieldnames = ['date', 'trans_id', 'customer_id', 'category', 'value']
        writer = csv.writer(csvfile)
        writer.writerow(fieldnames)
        for sale in sales:
            writer.writerow(sale)
    print(f"Sales records saved to {file_path}.")




# Style Section
def bold_text(text): # Function to display text in bold
    return "\033[1m" + text + "\033[0m"

def line_style_hyphen(length): # Function to make a line using hyphen by repeating the character
    print('-'*length)

def line_style_underscore(length): # Function to make line using under score by repeating the character
    print('_'*length)
    




