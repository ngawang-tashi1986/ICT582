from triangle import *  # Calling the program trangle which contain print_triangle() function

rows = int(input("Enter number of rows : "))
print_triangle(rows)

