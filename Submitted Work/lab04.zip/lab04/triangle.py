# Function to print triangle with given numbers of rows
def print_triangle(rows):
    for i in range(1, rows + 1):
        print('*' * i)