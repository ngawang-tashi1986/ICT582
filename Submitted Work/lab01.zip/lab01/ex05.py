fahrenheit = 60
celsius = (fahrenheit-32) * 5 / 9
print(celsius)

