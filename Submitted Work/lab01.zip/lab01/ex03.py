print('Name   : Ngawang Tashi Moktan')
print('City   : Thimphu')
print('Course : MIT Cyber Security')
print('Unit   : ICT581, Information System')
