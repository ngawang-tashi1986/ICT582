class TicketMachine:
    def __init__(self, price):
        if price < 0:
            raise ValueError("Ticket price cannot be negative")
        self.price = price
        self.balance = 0
        self.total = 0

    def insertMoney(self, amount):
        if amount < 0:
            raise ValueError("Amount cannot be negative")
        self.balance += amount

    def getPrice(self):
        print("Ticket price: $", self.price)
        return self.price

    def getBalance(self):
        print("Current balance: $", self.balance)
        return self.balance

    def printTicket(self):
        if self.balance >= self.price:
            print("Ticket printed!")
            self.total += self.price
            self.balance -= self.price
            self.balance = 0
        else:
            print("Insufficient balance. Please insert more money.")

    def getTotal(self):
        print("Total collected: $", self.total)
        return self.total

class TicketMachineSystem:
    def __init__(self):
        self.machines = []

    def addMachine(self, machine):
        self.machines.append(machine)

    def removeMachine(self, machine):
        self.machines.remove(machine)

    def getMachineTotal(self, machine):
        print("Total for machine:", machine.total)
        return machine.total

    def getTotalSales(self):
        total_sales = 0
        for machine in self.machines:
            total_sales += machine.total
        print("Total sales of all machines:", total_sales)
        return total_sales
    
# Create the ticket machine system
system = TicketMachineSystem()

# Create a new ticket machine with a price of $10
machine1 = TicketMachine(10)

# Add the machine to the system
system.addMachine(machine1)

# Insert $5 into the machine
machine1.insertMoney(5)

# Print the ticket
machine1.printTicket()

# Get the total for machine1
system.getMachineTotal(machine1)  # Output: Total for machine: 10

# Create another ticket machine with a price of $8
machine2 = TicketMachine(8)

# Add the second machine to the system
system.addMachine(machine2)

# Insert $10 into machine2
machine2.insertMoney(10)

# Print the ticket
machine2.printTicket()

# Get the total for machine2
system.getMachineTotal(machine2)  # Output: Total for machine: 8

# Remove machine1 from the system
system.removeMachine(machine1)

# Get the total sales of all machines
system.getTotalSales()  # Output: Total sales of all machines: 8