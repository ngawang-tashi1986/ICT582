class TicketMachine:
    def __init__(self, price):
        if price < 0:
            raise ValueError("Ticket price cannot be negative")
        self.price = price
        self.balance = 0
        self.total = 0

    def insertMoney(self, amount):
        if amount < 0:
            raise ValueError("Amount cannot be negative")
        self.balance += amount

    def getPrice(self):
        print("Ticket price: $", self.price)
        return self.price

    def getBalance(self):
        print("Current balance: $", self.balance)
        return self.balance

    def printTicket(self):
        if self.balance >= self.price:
            print("Ticket printed!")
            self.total += self.price
            self.balance -= self.price
            self.balance = 0
        else:
            print("Insufficient balance. Please insert more money.")

    def getTotal(self):
        print("Total collected: $", self.total)
        return self.total
    
# Create a ticket machine with a price of $10
tm = TicketMachine(10)

# Display the ticket price
tm.getPrice()  # Output: Ticket price: $ 10

# Insert $5 into the machine
tm.insertMoney(5)

# Display the current balance
tm.getBalance()  # Output: Current balance: $ 5

# Print the ticket
tm.printTicket()  # Output: Insufficient balance. Please insert more money.

# Insert $10 into the machine
tm.insertMoney(10)

# Print the ticket
tm.printTicket()  # Output: Ticket printed!

# Display the current balance (should be 0)
tm.getBalance()  # Output: Current balance: $ 0

# Display the total collected by the machine (should be $10)
tm.getTotal()  # Output: Total collected: $ 10