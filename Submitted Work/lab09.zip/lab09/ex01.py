class Fraction:
    def __init__(self, n, d):
        self.numerator = n
        if d == 0:
            raise Exception("Denominator cannot be 0")
        else:
            self.denominator = d
    
    def __str__(self):
        return str(self.numerator) + "/" + str(self.denominator)
    
    def __add__(self, other):
        f = Fraction(0, 1)
        f.numerator = self.numerator * other.denominator + other.numerator * self.denominator
        f.denominator = self.denominator * other.denominator
        return f
    
    def __sub__(self, other):
        f = Fraction(0, 1)
        f.numerator = self.numerator * other.denominator - other.numerator * self.denominator
        f.denominator = self.denominator * other.denominator
        return f
    
    def __eq__(self, other):
        if self.numerator / self.denominator == other.numerator / other.denominator:
            return True
        else:
            return False
        
    def to_float(self):
        return self.numerator / self.denominator
    
    def __truediv__(self, other):
        if other.numerator == 0:
            raise ZeroDivisionError("Cannot divide by zero.")
        f = Fraction(0, 1)
        f.numerator = self.numerator * other.denominator
        f.denominator = self.denominator * other.numerator
        return f
    
    def invert(self):
        if self.numerator == 0:
            raise ZeroDivisionError("Cannot invert fraction with numerator 0.")
        f = Fraction(self.denominator, self.numerator)
        return f
    
# Create fraction objects
f1 = Fraction(2, 3)
f2 = Fraction(3, 4)
f3 = Fraction(5, 6)

# Convert fractions to float
print(f1.to_float())  # Output: 0.6666666666666666

# Perform division
result = f1 / f2
print(result)  # Output: 8/9

# Invert fractions
inverted = f3.invert()
print(inverted)  # Output: 6/5