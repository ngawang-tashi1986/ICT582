import csv
import os

fileName = "staff.csv"

try:
    with open(fileName, 'r') as csvfile:
        reader = csv.reader(csvfile)
        headers = next(reader)

        for row in reader:
            staff_name = row[1]
            phone_number = row[2]
            home_address = row[3]

            try:
                if not row[0]:
                    raise Exception("\n Ignoring record with missing staff id: %s" % row)
                print()
                print("Name         : " + staff_name)
                print("Phone Number : " + phone_number)
                print("Address      : " + home_address)
                print()
            except Exception as e:
                print("Error: " + str(e))

except FileNotFoundError:
    print("Error!!! staff.csv file not found")
except IOError:
    print("Error!!! Unable to open the file")
except:
    print("Error!!! Uncaught error here")





