def print_triangle(n):
    get_sequence = ''.join(str(i) for i in range(1, n+1))
    try:
        assert type(n) == int and 1 <= n <= 9, "n must be an integer in the range of 1 and 9 (inclusive)"
        for i in range(len(get_sequence), 0, -1):  # Decrement to print in reverse
            for j in range(i):                     # Inner loop for printing each digit in a row
                print(get_sequence[j], end='')     # Print digit with no newline
            print()
    except AssertionError as msg:
        print(msg)


rows = int(input("Enter number of rows: "))
print_triangle(rows)