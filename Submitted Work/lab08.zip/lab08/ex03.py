# Function to copy content from one file to another
def copy_file(source_file, destination_file):
    try:
        with open(source_file, "r") as source:
            content = source.read()

        with open(destination_file, "w") as destination:
            destination.write(content)

        print(f"File '{source_file}' has been successfully copied to '{destination_file}'.")
    except FileNotFoundError:
        print(f"Error: The file '{source_file}' does not exist. ")
    except IOError:
        print("Cannot read or write the file")
    except:
        print("Unexpected error happened with copying the file")

# Source and destination file names
source_file = "foo.txt"
destination_file = "bar.txt"

# Call the function to perform the file copy
copy_file(source_file, destination_file)
